<?php $__env->startSection('content'); ?>

    <title>Applicants</title>

    <table>
        <?php $__currentLoopData = $applicant_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-gray-800  text-white">
                <div class="grid grid-cols-1 md:grid-cols-2">
                    <div class="p-6">
                        <div class="flex items-center">
                            <div class="ml-4 text-lg leading-7 font-semibold">
                                <ul>
                                    <li>name-<?php echo e($applicant->name); ?>,</li>
                                    <li>username-<?php echo e($applicant->username); ?>,</li>
                                    <li>position-<?php echo e($applicant->position); ?>,</li>
                                    <li>phone-<?php echo e($applicant->phone); ?>,</li>
                                    <li>is_hired-<?php echo e($applicant->is_hired); ?>,</li>
                                </ul>
                            </div>
                            <div class="ml-4 text-lg leading-7 font-semibold">
                                <a href="<?php echo e(route('applicant.edit', $applicant->id)); ?>" class="underline text-gray-900 dark:text-white">
                                    <i class="fa fa-pencil-scuare text-white">edit</i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luka/Desktop/shualeduri/shualeduri/resources/views/applicant_list.blade.php ENDPATH**/ ?>
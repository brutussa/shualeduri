<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-700">
<?php echo $__env->yieldContent('content'); ?>
</body>
<?php /**PATH /home/luka/Desktop/shualeduri/shualeduri/resources/views/home.blade.php ENDPATH**/ ?>